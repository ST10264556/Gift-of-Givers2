using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class Volunteer
    {
        [Key]
        public int VolunteerID { get; set; }

        [Required]
        public string Name { get; set; }

        public string Email { get; set; }

        public ICollection<VolunteerTask> Assignments { get; set; }
    }
}


