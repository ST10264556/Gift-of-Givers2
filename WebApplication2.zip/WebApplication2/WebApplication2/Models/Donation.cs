﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class Donation
    {
        [Key]
        public int DonationID { get; set; }

        [Required]
        public string ResourceType { get; set; } // e.g., "Food", "Clothing", "Cash"

        public int Quantity { get; set; }        // units or amount for Cash

        public DateTime DateDonated { get; set; } = DateTime.UtcNow;

        // Link to user (uses int Id in ApplicationUser)
        public int? DonorId { get; set; }
        public ApplicationUser Donor { get; set; }

        public string Note { get; set; }         // optional description
    }
}
