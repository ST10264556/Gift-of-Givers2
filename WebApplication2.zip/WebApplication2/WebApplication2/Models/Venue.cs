﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class Venue
    {
        [Key]
        public int VenueID { get; set; }

        [Required]
        public string Name { get; set; }
        public string Address { get; set; }

        public ICollection<Gig> Gigs { get; set; }
    }
}
