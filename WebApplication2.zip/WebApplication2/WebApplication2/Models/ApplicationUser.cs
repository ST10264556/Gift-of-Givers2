﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class ApplicationUser
    {
        [Key]
        public int Id { get; set; }          // maps to your DB user PK
        [Required, StringLength(100)]
        public string Username { get; set; }
        [Required, EmailAddress]
        public string Email { get; set; }

        // We'll store a hashed password
        public string PasswordHash { get; set; }

        public string FullName { get; set; }
        [Required]
        public string Role { get; set; }     // "Admin", "User", "Volunteer"
    }
}
