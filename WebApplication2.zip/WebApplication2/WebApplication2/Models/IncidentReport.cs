using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class IncidentReport
    {
        [Key]
        public int IncidentReportID { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        public string Location { get; set; }

        public DateTime ReportedAt { get; set; } = DateTime.UtcNow;

        public int? ReporterUserId { get; set; }
        public ApplicationUser Reporter { get; set; }
    }
}


