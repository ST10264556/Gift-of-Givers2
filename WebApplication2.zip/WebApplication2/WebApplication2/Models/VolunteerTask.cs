using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class VolunteerTask
    {
        [Key]
        public int VolunteerTaskID { get; set; }

        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        public DateTime? ScheduledAt { get; set; }

        public int? VolunteerID { get; set; }
        public Volunteer Volunteer { get; set; }
    }
}


