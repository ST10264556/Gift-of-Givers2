using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<ApplicationUser> Users { get; set; }
        public DbSet<Donation> Donations { get; set; }
        public DbSet<Gig> Gigs { get; set; }
        public DbSet<DJ> DJs { get; set; }
        public DbSet<Venue> Venues { get; set; }
        public DbSet<IncidentReport> IncidentReports { get; set; }
        public DbSet<Volunteer> Volunteers { get; set; }
        public DbSet<VolunteerTask> VolunteerTasks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ApplicationUser>(entity =>
            {
                entity.HasIndex(u => u.Username).IsUnique();
                entity.Property(u => u.Username).IsRequired();
                entity.Property(u => u.Email).IsRequired();
            });

            modelBuilder.Entity<Donation>(entity =>
            {
                entity.HasOne(d => d.Donor)
                      .WithMany()
                      .HasForeignKey(d => d.DonorId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<Gig>(entity =>
            {
                entity.HasOne(g => g.DJ)
                      .WithMany(d => d.Gigs)
                      .HasForeignKey(g => g.DJID)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(g => g.Venue)
                      .WithMany(v => v.Gigs)
                      .HasForeignKey(g => g.VenueID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<IncidentReport>(entity =>
            {
                entity.HasOne(i => i.Reporter)
                      .WithMany()
                      .HasForeignKey(i => i.ReporterUserId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<VolunteerTask>(entity =>
            {
                entity.HasOne(t => t.Volunteer)
                      .WithMany(v => v.Assignments)
                      .HasForeignKey(t => t.VolunteerID)
                      .OnDelete(DeleteBehavior.SetNull);
            });
        }
    }
}


