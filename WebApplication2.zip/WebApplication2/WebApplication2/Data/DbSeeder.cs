using System.Linq;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Data
{
    public static class DbSeeder
    {
        public static void Seed(ApplicationDbContext db)
        {
            try
            {
                db.Database.EnsureCreated();

                if (!db.Set<DJ>().Any())
                {
                    db.Set<DJ>().AddRange(new []
                    {
                        new DJ { StageName = "DJ Alpha" },
                        new DJ { StageName = "DJ Beta" },
                        new DJ { StageName = "DJ Gamma" }
                    });
                }

                if (!db.Set<Venue>().Any())
                {
                    db.Set<Venue>().AddRange(new []
                    {
                        new Venue { Name = "City Hall", Address = "123 Main St" },
                        new Venue { Name = "Riverside Park", Address = "45 River Rd" }
                    });
                }

                // Seed sample incident reports
                if (!db.Set<IncidentReport>().Any())
                {
                    db.Set<IncidentReport>().AddRange(new []
                    {
                        new IncidentReport { Title = "Flood in Downtown", Description = "Heavy flooding reported in downtown area", Location = "Main Street" },
                        new IncidentReport { Title = "Power Outage", Description = "Widespread power outage affecting residential areas", Location = "North District" }
                    });
                }

                // Seed sample volunteers
                if (!db.Set<Volunteer>().Any())
                {
                    db.Set<Volunteer>().AddRange(new []
                    {
                        new Volunteer { Name = "John Smith", Email = "john@example.com" },
                        new Volunteer { Name = "Jane Doe", Email = "jane@example.com" }
                    });
                }

                db.SaveChanges();
            }
            catch
            {
                // If seeding fails (e.g., remote DB permissions), skip without blocking app startup
            }
        }
    }
}
