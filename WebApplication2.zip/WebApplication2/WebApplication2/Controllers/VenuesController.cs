using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class VenuesController : Controller
    {
        private readonly ApplicationDbContext _db;
        public VenuesController(ApplicationDbContext db) { _db = db; }

        public async Task<IActionResult> Index()
        {
            var venues = await _db.Venues.ToListAsync();
            return View(venues);
        }

        [HttpGet]
        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Venue model)
        {
            if (!ModelState.IsValid) return View(model);
            _db.Venues.Add(model);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var venue = await _db.Venues.FindAsync(id);
            if (venue == null) return RedirectToAction(nameof(Index));
            return View(venue);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Venue model)
        {
            if (!ModelState.IsValid) return View(model);
            _db.Venues.Update(model);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}


