﻿using WebApplication2.Data;
using WebApplication2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace WebApplication2.Controllers
{
    public class GigsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public GigsController(ApplicationDbContext db) { _db = db; }

        public async Task<IActionResult> Index()
        {
            var gigs = await _db.Gigs.Include(g => g.DJ).Include(g => g.Venue).ToListAsync();
            return View(gigs);
        }

        public IActionResult Create()
        {
            ViewData["DJs"] = new SelectList(_db.DJs.ToList(), "DJID", "StageName");
            ViewData["Venues"] = new SelectList(_db.Venues.ToList(), "VenueID", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Gig gig)
        {
            if (!ModelState.IsValid)
            {
                ViewData["DJs"] = new SelectList(_db.DJs.ToList(), "DJID", "StageName", gig.DJID);
                ViewData["Venues"] = new SelectList(_db.Venues.ToList(), "VenueID", "Name", gig.VenueID);
                return View(gig);
            }

            _db.Gigs.Add(gig);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
