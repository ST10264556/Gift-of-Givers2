using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Authorize]
    public class ProfileController : Controller
    {
        private readonly ApplicationDbContext _db;
        public ProfileController(ApplicationDbContext db) { _db = db; }

        public async Task<IActionResult> Index()
        {
            var idStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (!int.TryParse(idStr, out int userId)) return RedirectToAction("Login", "Account");
            var user = await _db.Users.FindAsync(userId);
            return View(user);
        }

        [HttpGet]
        public async Task<IActionResult> Edit()
        {
            var idStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (!int.TryParse(idStr, out int userId)) return RedirectToAction("Login", "Account");
            var user = await _db.Users.FindAsync(userId);
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ApplicationUser model)
        {
            if (!ModelState.IsValid) return View(model);
            var user = await _db.Users.FindAsync(model.Id);
            if (user == null) return RedirectToAction("Index");
            user.FullName = model.FullName;
            user.Email = model.Email;
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}


