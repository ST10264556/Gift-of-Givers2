using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class IncidentsController : Controller
    {
        private readonly ApplicationDbContext _db;
        public IncidentsController(ApplicationDbContext db) { _db = db; }

        public async Task<IActionResult> Index()
        {
            var list = await _db.IncidentReports
                                 .Include(i => i.Reporter)
                                 .OrderByDescending(i => i.ReportedAt)
                                 .ToListAsync();
            return View(list);
        }

        [Authorize]
        public IActionResult Create() => View();

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(IncidentReport model)
        {
            if (!ModelState.IsValid) return View(model);
            var idStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (int.TryParse(idStr, out int userId)) model.ReporterUserId = userId;
            model.ReportedAt = DateTime.UtcNow;
            _db.IncidentReports.Add(model);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}


