﻿using WebApplication2.Data;
using WebApplication2.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace WebApplication2.Controllers
{
    public class DonationsController : Controller
    {
        private readonly ApplicationDbContext _db;

        public DonationsController(ApplicationDbContext db) { _db = db; }

        // GET: /Donations
        public async Task<IActionResult> Index()
        {
            var list = await _db.Donations.Include(d => d.Donor).OrderByDescending(d => d.DateDonated).ToListAsync();
            return View(list);
        }

        // GET: /Donations/Create
        [Authorize]
        public IActionResult Create() => View();

        // POST: /Donations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Create(Donation model)
        {
            if (!ModelState.IsValid) return View(model);

            // get logged-in user id
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdClaim, out int userId))
            {
                // fallback or error
                ModelState.AddModelError("", "Unable to identify user.");
                return View(model);
            }

            model.DonorId = userId;
            model.DateDonated = DateTime.UtcNow;

            _db.Donations.Add(model);
            await _db.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
