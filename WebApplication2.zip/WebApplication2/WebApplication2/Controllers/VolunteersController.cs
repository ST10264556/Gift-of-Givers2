using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class VolunteersController : Controller
    {
        private readonly ApplicationDbContext _db;
        public VolunteersController(ApplicationDbContext db) { _db = db; }

        public async Task<IActionResult> Index()
        {
            var volunteers = await _db.Volunteers.Include(v => v.Assignments).ToListAsync();
            return View(volunteers);
        }

        [HttpGet]
        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Volunteer model)
        {
            if (!ModelState.IsValid) return View(model);
            _db.Volunteers.Add(model);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}


